# Gordon's Blocky Kitchen

A tiny browser game where you help Gordon Ramsay craft Minecraft-inspired dishes under rising time pressure. Tap or click the ingredients to finish recipes before the service timer expires, and keep an eye on the wandering zombie sous-chef in his chef's hat.

## Playing locally

Just open `index.html` in your favourite browser (desktop or mobile) and the pixel kitchen will load immediately.
